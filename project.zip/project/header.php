 <?php
 include ("linkfile.php");
   ?>
 <div class="panel panel-default">
      <div class="panel-heading">
	  <h1>
     <span style="font-family: New Century Schoolbook, TeX Gyre Schola, serif;color: #3B0B0B"><img src='logo.jpg'/> Matrimonial Sites</span>
     <button class='btn btn-danger pull-right' data-toggle="modal" data-target="#myModal">New User</button>
    </h1>
	    </div>
	    </div>
       
    <div class="header">
  
  <nav class="navbar">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" >
        <span class="icon-bar" style="background-color: black"></span>
        <span class="icon-bar" style="background-color: black"></span>
        <span class="icon-bar" style="background-color: black"></span>
      </button>
      <a class="navbar-brand" href="#" style="color: black;">WebSiteName</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php" style="color: black">Home</a></li>
        <li><a href="profile.php" style="color: black;">Profile</a></li>
        <li><a href="about_us.php" style="color: black;">About Us</a></li>
        <li><a href="contact_us.php" style="color: black;">Contact Us</a></li>
        <li><a href="srch.php" style="color: black;">View All</a></li>
      </ul>
      
    </div>
  </div>
</nav>
</div>
	   
 


 <?php
include ("modal.php");
 ?>
 