<?php
$arr=array("SERVER","LOCALHOST");
print_r($arr);
if(in_array("SERVER",$arr))
ECHO "status=";
else
echo "not found";	

?>