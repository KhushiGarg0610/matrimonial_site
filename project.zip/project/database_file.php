<?php
 			define('SERVER','127.0.0.1');
 			define('DB_USERID','admin');
 			define('DB_PASSWORD','spic1123');
 			define('DATABASE','test');
 			?>