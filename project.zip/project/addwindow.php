

<?php
include ("linkfile.php");

// for($i=0;$i<3;$i++){
 echo"

<div class='col-md-4'>
<div class='panel panel-danger'>
      <div class='panel-heading'>Success Story 1</div>
      <div class='panel-body'>
      <img src='images/13.jpg' class='img-responsive'>
	 </div>
    </div>
  </div>

  <div class='col-md-4'>
<div class='panel panel-danger'>
      <div class='panel-heading'>Success Story 2</div>
      <div class='panel-body'>
      <img src='images/14.jpg' class='img-responsive'>
	 </div>
    </div>
  </div>

  <div class='col-md-4'>
<div class='panel panel-danger'>
      <div class='panel-heading'>Success Story 3</div>
      <div class='panel-body'>
      <img src='images/15.jpg' class='img-responsive'>
	 </div>
    </div>
  </div>

 
    ";
// }
?>
 