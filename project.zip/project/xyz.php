<!-- // 	// 	);
	

// //}
// // echo "Test File<br/>";
// // $f1=fopen("mynew_txt.txt","w");
// // fwrite($f1, "hello spic");
// // fclose($f1);
// // echo phpinfo();
// /*$obj1=new lib();
// $obj1->set_value(8,9);
// $obj2=new lib();
// $obj2->set_value(5,7);
// echo "1st object output<br/>";
// $obj1->get_value();
// echo "2nd object output<br/>";
// $obj2->get_value();
// /*$str=base64_encode("spic123#");
// echo "str1=$str<br/>";
// $str=base64_encode("spic123#");
// echo "str1=$str<br/>";

// echo "spic123#<br/>";
// $test_value=$obj1->my_encode('spic123#');
// echo "<br/>test_value=$test_value";
// /*echo "<br/>case1 <br/>encode_value=:$test_value";
// $obj2=new mylib();
// $test_value=$obj2->my_encode('spic123#');
// echo "<br/>case 2<br/>encode_value=:$test_value";
// */

// //$obj1->sum(2,3,4,5);
// /* $col_list="*";
// $where_con="empid='12'";
// $status=$obj1->find("empinfo",$col_list,$where_con);
// if($status!=1)
// {
// 	echo "Error=".$obj1->get_error();
// }
// else
// {
// 	echo $obj1->get_num_rows();
// 	$data=$obj1->get_data();
// 	echo "empname=".$data[1];
// 	echo "<br/>empsalary".$data[2];
// 	echo "<br/>empid=".$data[0];
// //	print_r($data);
// }
// */

// /*
// $obj->set_fname('kamal');
// $obj->set_lname(' dhiman');
// $str=$obj->get_value();
// echo "$str";*/
// /*require_once ("oopsinser.php");
// $obj= new demo();
// $obj->get_value(); */

